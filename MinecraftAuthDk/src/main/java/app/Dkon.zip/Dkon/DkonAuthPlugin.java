/*import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class DkonAuthPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        getLogger().info("DkonAuthPlugin включен!");
    }

    @Override
    public void onDisable() {
        getLogger().info("DkonAuthPlugin выключен!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("login") && sender instanceof Player) {
            if (args.length != 2) {
                sender.sendMessage("Используйте: /login <username> <password>");
                return true;
            }
            String username = args[0];
            String password = args[1];
            authenticatePlayer((Player) sender, username, password);
            return true;
        }
        return false;
    }

    private void authenticatePlayer(Player player, String username, String password) {
        new Thread(() -> {
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                HttpPost post = new HttpPost("https://api.dkon.app/api/v3/method/account.signIn");
                post.setHeader("Content-Type", "application/json");
                JsonObject json = new JsonObject();
                json.addProperty("clientId", 1302);
                json.addProperty("username", username);
                json.addProperty("password", password);
                post.setEntity(new StringEntity(json.toString()));

                try (CloseableHttpResponse response = client.execute(post)) {
                    String jsonResponse = EntityUtils.toString(response.getEntity());
                    JsonObject responseObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

                    if (responseObject.get("error").getAsBoolean()) {
                        player.sendMessage("Ошибка авторизации!");
                    } else {
                        String accessToken = responseObject.get("accessToken").getAsString();
                      //  player.sendMessage("Успешная авторизация! Токен: " + accessToken); accountId
                          player.sendMessage("Успешная авторизация! Ваш Id в Базе: " + accountId);
                    }
                }
                            } catch (Exception e) {
                    player.sendMessage("Произошла ошибка при попытке авторизации: " + e.getMessage());
                    getLogger().severe("Ошибка при авторизации игрока " + player.getName() + ": " + e.getMessage());
                }
            }).start();
        }
    
    
    ///addd
    
    private void registerPlayer(Player player, String username, String fullname, String password, String email) {
    // Валидация параметров
    if (!isValidUsername(username)) {
        player.sendMessage("Ошибка: Логин должен содержать только английские буквы, цифры и символ '_', и быть от 6 до 10 символов.");
        return;
    }
    if (fullname.length() < 1) {
        player.sendMessage("Ошибка: Полное имя не может быть пустым.");
        return;
    }
    if (password.length() < 6) {
        player.sendMessage("Ошибка: Пароль должен содержать минимум 6 символов.");
        return;
    }
    if (!isValidEmail(email)) {
        player.sendMessage("Ошибка: Неверный формат email.");
        return;
    }

    new Thread(() -> {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost("https://api.dkon.app/api/v2/method/account.signUp");
            post.setHeader("Content-Type", "application/json");

            String fcmRegId = generateRandomString(6, 10);
            JsonObject json = new JsonObject();
            json.addProperty("clientId", 1302);
            json.addProperty("fcm_regId", fcmRegId);
            json.addProperty("username", username);
            json.addProperty("fullname", fullname);
            json.addProperty("password", password);
            json.addProperty("email", email + "@mplug.dkon.app");
            post.setEntity(new StringEntity(json.toString()));

            try (CloseableHttpResponse response = client.execute(post)) {
                String jsonResponse = EntityUtils.toString(response.getEntity());
                JsonObject responseObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

                if (responseObject.get("error").getAsBoolean()) {
                    int errorCode = responseObject.get("error_code").getAsInt();
                    if (errorCode == 300) {
                        player.sendMessage("Ошибка: Логин уже занят.");
                    } else {
                        player.sendMessage("Ошибка регистрации: " + responseObject.get("error_description").getAsString());
                    }
                } else {
                    String accessToken = responseObject.get("accessToken").getAsString();
                    player.sendMessage("Регистрация успешна! Добро пожаловать, " + fullname + "!");
                }
            }
        } catch (Exception e) {
            player.sendMessage("Произошла ошибка при попытке регистрации: " + e.getMessage());
            getLogger().severe("Ошибка при регистрации игрока " + player.getName() + ": " + e.getMessage());
        }
    }).start();
}

private boolean isValidUsername(String username) {
    return username.matches("^[a-zA-Z0-9_]{6,10}$");
}

private boolean isValidEmail(String email) {
    return email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.mplug\\.dkon\\.app$");
}

    
    
    
    private void checkUsername(Player player, String username, String password, String email) {
    new Thread(() -> {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost("https://api.dkon.app/api/v3/method/app.checkUsername");
            post.setHeader("Content-Type", "application/json");

            JsonObject json = new JsonObject();
            json.addProperty("username", username);
            post.setEntity(new StringEntity(json.toString()));

            try (CloseableHttpResponse response = client.execute(post)) {
                String jsonResponse = EntityUtils.toString(response.getEntity());
                JsonObject responseObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

                if (responseObject.get("error").getAsBoolean()) {
                    // Имя пользователя уже занято
                    player.sendMessage("Ошибка: Логин уже занят.");
                } else {
                    // Имя пользователя свободно, продолжаем регистрацию
                    registerPlayer(player, username, password, email);
                }
            }
        } catch (Exception e) {
            player.sendMessage("Произошла ошибка при проверке логина: " + e.getMessage());
            getLogger().severe("Ошибка при проверке логина игрока " + player.getName() + ": " + e.getMessage());
        }
    }).start();
}

    
    
    private void checkUsername(Player player, String username, String password, String email) {
    new Thread(() -> {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost("https://api.dkon.app/api/v3/method/app.checkUsername");
            post.setHeader("Content-Type", "application/json");

            JsonObject json = new JsonObject();
            json.addProperty("username", username);
            post.setEntity(new StringEntity(json.toString()));

            try (CloseableHttpResponse response = client.execute(post)) {
                String jsonResponse = EntityUtils.toString(response.getEntity());
                JsonObject responseObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

                if (responseObject.get("error").getAsBoolean()) {
                    // Имя пользователя уже занято
                    player.sendMessage("Ошибка: Логин уже занят.");
                } else {
                    // Имя пользователя свободно, продолжаем регистрацию
                    registerPlayer(player, username, password, email);
                }
            }
        } catch (Exception e) {
            player.sendMessage("Произошла ошибка при проверке логина: " + e.getMessage());
            getLogger().severe("Ошибка при проверке логина игрока " + player.getName() + ": " + e.getMessage());
        }
    }).start();
}

    
    
    
    ///end add
    }
}
*/
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.security.SecureRandom;

public class DkonAuthPlugin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getLogger().info("DkonAuthPlugin включен!");
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        getLogger().info("DkonAuthPlugin выключен!");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        checkUsername(player);
    }

    private void checkUsername(Player player) {
        new Thread(() -> {
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                HttpPost post = new HttpPost("https://api.dkon.app/api/v3/method/app.checkUsername");
                post.setHeader("Content-Type", "application/json");

                JsonObject json = new JsonObject();
                json.addProperty("username", player.getName());
                post.setEntity(new StringEntity(json.toString()));

                try (CloseableHttpResponse response = client.execute(post)) {
                    String jsonResponse = EntityUtils.toString(response.getEntity());
                    JsonObject responseObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

                    if (responseObject.get("error").getAsBoolean()) {
                        // Игрок не зарегистрирован
                        player.sendMessage("Вы не зарегистрированы. Пожалуйста, используйте команду /register <password> <email> для регистрации.");
                    } else {
                        // Игрок зарегистрирован
                        player.sendMessage("Вы зарегистрированы. Пожалуйста, используйте команду /login <password> для авторизации.");
                    }
                }
            } catch (Exception e) {
                player.sendMessage("Произошла ошибка при проверке логина: " + e.getMessage());
                getLogger().severe("Ошибка при проверке логина игрока " + player.getName() + ": " + e.getMessage());
            }
        }).start();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("login") && sender instanceof Player) {
            if (args.length != 2) {
                sender.sendMessage("Используйте: /login <password>");
                return true;
            }
            String password = args[1];
            authenticatePlayer((Player) sender, password);
            return true;
        } else if (cmd.getName().equalsIgnoreCase("register") && sender instanceof Player) {
            if (args.length != 2) {
                sender.sendMessage("Используйте: /register <password> <email>");
                return true;
            }
            String password = args[1];
            String email = args[2];
            registerPlayer((Player) sender, player.getName(), password, email);
            return true;
        }
        return false;
    }

    private void authenticatePlayer(Player player, String password) {
        new Thread(() -> {
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                HttpPost post = new HttpPost("https://api.dkon.app/api/v3/method/account.signIn");
                post.setHeader("Content-Type", "application/json");
                JsonObject json = new JsonObject();
                json.addProperty("clientId", 1302);
                json.addProperty("username", player.getName());
                json.addProperty("password", password);
                post.setEntity(new StringEntity(json.toString()));

                try (CloseableHttpResponse response = client.execute(post)) {
                    String jsonResponse = EntityUtils.toString(response.getEntity());
                    JsonObject responseObject = Json
